#!/bin/bash

echo "[+] memo-drive - start"
echo `nohup python index.py &`